CREATE VIEW `quick1` AS
  SELECT
    `vids`.`webvidsxham`.`stringkey` AS `stringkey`,
    `vids`.`webvidsxham`.`host`      AS `host`
  FROM `vids`.`webvidsxham`